<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title" key="t-menu">Menu</li>
                @if (Auth::user()->role == 'Admin')
                <li>
                    <a href="#">
                        <i class="bx bx-list-ul"></i>
                        <span key="t-tables">Dashboards</span>
                    </a>
                </li>
                <li>
                    <a href="{{route('patient.index')}}">
                        <i class="bx bx-list-ul"></i>
                        <span key="t-tables">Patient</span>
                    </a>
                </li>
                <li>
                    <a href="{{route('assistant.index')}}">
                        <i class="bx bx-list-ul"></i>
                        <span key="t-tables">Assistant</span>
                    </a>
                </li>
                @elseif (Auth::user()->role == 'Assistant')
                <li>
                    <a href="{{route('assistantPatient')}}">
                        <i class="bx bx-list-ul"></i>
                        <span key="t-tables">Patient</span>
                    </a>
                </li>
                @endif
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->

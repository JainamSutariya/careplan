/*
Template Name: Skote - Admin & Dashboard Template
Author: Themesbrand
Website: https://themesbrand.com/
Contact: themesbrand@gmail.com
File: ecommerce cart Js File
*/

//Bootstrap-TouchSpin
$("input[name='demo_vertical']").TouchSpin({
    verticalbuttons: true
});
<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title" key="t-menu">Menu</li>
                <?php if(Auth::user()->role == 'Admin'): ?>
                <li>
                    <a href="#">
                        <i class="bx bx-list-ul"></i>
                        <span key="t-tables">Dashboards</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('patient.index')); ?>">
                        <i class="bx bx-list-ul"></i>
                        <span key="t-tables">Patient</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('assistant.index')); ?>">
                        <i class="bx bx-list-ul"></i>
                        <span key="t-tables">Assistant</span>
                    </a>
                </li>
                <?php elseif(Auth::user()->role == 'Assistant'): ?>
                <li>
                    <a href="<?php echo e(route('assistantPatient')); ?>">
                        <i class="bx bx-list-ul"></i>
                        <span key="t-tables">Patient</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH E:\careplan\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>
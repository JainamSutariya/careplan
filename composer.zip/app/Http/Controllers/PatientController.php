<?php

namespace App\Http\Controllers;

use App\Models\AdaptedWalsallScore;
use App\Models\Allergies;
use App\Models\Communication;
use App\Models\ContinenceCare;
use App\Models\CovidTest;
use App\Models\DietaryRisk;
use App\Models\DressingSupport;
use App\Models\EmergencyActionPlan;
use App\Models\EndLife;
use App\Models\EnviromentalRisk;
use App\Models\ExtraNeed;
use App\Models\FallsRisk;
use App\Models\FireSafetyRisk;
use App\Models\GeneralTidyUp;
use App\Models\Medication;
use App\Models\MedicationRisk;
use App\Models\Mobility;
use App\Models\MobilityAndTransferRisk;
use App\Models\MyHealth;
use App\Models\MyInformation;
use App\Models\MyLifeStyle;
use App\Models\MyPreferredCallSupport;
use App\Models\NutritionHydration;
use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\PersonalCare;
use Yajra\DataTables\DataTables;
use App\Models\User;
use App\Models\PersonalContactDetails;
use App\Models\PressureUlcerRecord;
use App\Models\RestraintRisk;
use App\Models\SkinCare;
use App\Models\SocialInterestActivities;
use App\Models\WashAndShower;
use Carbon\Carbon;

class PatientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('patient.index');
    }

    public function getPatient(Request $request)
    {
        if ($request->ajax()) {
            $data = Patient::all();
            return Datatables::of($data)
                ->addIndexColumn()
                ->editColumn('status', function ($status) {
                    return $status->status == 1 ? 'Active' : 'Inactive';
                })
                ->addColumn('action', function($row){
                    $btn = '<ul class="list-unstyled hstack gap-1 mb-0"><li data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><a href="patient/'.$row->id.'/edit" class="btn btn-sm btn-soft-info"><i class="mdi mdi-pencil-outline"></i></a></li><li data-bs-toggle="tooltip" data-bs-placement="top" aria-label="Delete" onclick="setDelete('.$row->id.')"><a href="#jobDelete" data-bs-toggle="modal" class="btn btn-sm btn-soft-danger"><i class="mdi mdi-delete-outline"></i></a></li></ul>';
                    return $btn;
                })
                ->addColumn('button', function($row){
                    $button = '<a href="care-plan/'.$row->id.'" class="btn btn-primary w-md">Risk Assessment</a>';
                    return $button;
                })
                ->rawColumns(['action', 'status', 'button'])
                ->make(true);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $assistantList = User::where('role', 'Assistant')->get();
        return view('patient.create', compact('assistantList'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        dd($request->all());
        $request->validate([
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
        ]);
        $requestData = $request->all();
        if ($request->status == "on") {
            $requestData['status'] = 1;
        } else {
            $requestData['status'] = 0;
        }
        $requestData['dob'] = Carbon::createFromFormat('d-m-Y', $requestData['dob'])->format('Y-m-d');
        Patient::create($requestData);
        return redirect()->route('patient.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $patient = Patient::find($id);
        $assistantList = User::where('role', 'Assistant')->get();
        return view('patient.edit', compact('patient', 'assistantList'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
        ]);
        $requestData = $request->all();
        if ($request->status == "on") {
            $requestData['status'] = 1;
        } else {
            $requestData['status'] = 0;
        }
        $requestData['dob'] = Carbon::createFromFormat('d-m-Y', $requestData['dob'])->format('Y-m-d');
        Patient::find($id)->update($requestData);
        return redirect()->route('patient.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id, Request $request)
    {
        if ($request->ajax()) {
            $patient = Patient::find($id);
            if ($patient) {
                $patient->delete();
                return response()->json([
                    'status'  => 200,
                    'message' => "Customer Deleted Successfully",
                ]);
            }
            return response()->json([
                'status'  => 500,
                'message' => "Unable to Delete Customer",
            ]);
        }
    }

    public function dashboards(Request $request) {

    }

    public function careplan($id) {
        $patient = Patient::find($id);
        return view('patient.careplan', compact('patient'));
    }

    public function personalCare($id) {
        $patient = Patient::find($id);
        $personalCare = PersonalCare::where('patient_id', $id)->first();
        $checkedValues = $personalCare->care_support_need ?? null;
        if ($checkedValues !== null) {
            $checkedValues = json_decode($checkedValues);
        }
        $otherCheckedValues = $personalCare->while_seated ?? null;
        if ($otherCheckedValues !== null) {
            $otherCheckedValues = json_decode($otherCheckedValues);
        }
        $otherCheckedValues1 = $personalCare->shaving_support_need ?? null;
        if ($otherCheckedValues1 !== null) {
            $otherCheckedValues1 = json_decode($otherCheckedValues1);
        }
        return view('patient.personal-care', compact('patient', 'personalCare', 'checkedValues', 'otherCheckedValues', 'otherCheckedValues1'));
    }

    public function storePersonalCare(Request $request, $id) {
        $requestData = $request->all();
        if (isset($requestData['other_outcomes_check'])) {
            $requestData['other_outcomes_check'] = json_encode($requestData['other_outcomes_check']);
        }
        if (isset($requestData['other_outcomes_text'])) {
            $requestData['other_outcomes_text'] = json_encode($requestData['other_outcomes_text']);
        }
        if (isset($requestData['care_support_need'])) {
            $requestData['care_support_need'] = json_encode($requestData['care_support_need']);
        }
        if (isset($requestData['while_seated'])) {
            $requestData['while_seated'] = json_encode($requestData['while_seated']);
        }
        if (isset($requestData['shaving_support_need'])) {
            $requestData['shaving_support_need'] = json_encode($requestData['shaving_support_need']);
        }
        PersonalCare::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('personalCare', ['id' => $id]);
    }

    public function covid19($id) {
        $patient = Patient::find($id);
        $covidTest = CovidTest::where('patient_id', $id)->first();
        return view('patient.covid-19', compact('patient', 'covidTest'));
    }

    public function storeCovid19(Request $request, $id) {
        $requestData = $request->all();
        $requestData['when_service_user_tested_date'] = Carbon::createFromFormat('d-m-Y', $requestData['when_service_user_tested_date'])->format('Y-m-d');
        CovidTest::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('covid19', ['id' => $id]);
    }

    public function communication($id) {
        $patient = Patient::find($id);
        $communication = Communication::where('patient_id', $id)->first();
        return view('patient.communication', compact('patient', 'communication'));
    }

    public function storeCommunication(Request $request, $id) {
        Communication::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('communication', ['id' => $id]);
    }

    public function personalContact($id) {
        $patient = Patient::find($id);
        $patientDetails = PersonalContactDetails::where('patient_id', $id)->first();
        return view('patient.personal-contact-details', compact('patient', 'patientDetails'));
    }

    public function storePersonalContact(Request $request, $id) {
        PersonalContactDetails::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('personalContact', ['id' => $id]);
    }

    public function myInformation($id) {
        $patient = Patient::find($id);
        $myInformation = MyInformation::where('patient_id', $id)->first();
        return view('patient.my-information', compact('patient', 'myInformation'));
    }

    public function storeMyInformation(Request $request, $id) {
        MyInformation::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('myInformation', ['id' => $id]);
    }

    public function enviromentalRisk($id) {
        $patient = Patient::find($id);
        $enviromentalRisk = EnviromentalRisk::where('patient_id', $id)->first();
        return view('patient.enviromental-risk', compact('patient', 'enviromentalRisk'));
    }

    public function storeEnviromentalRisk(Request $request, $id) {
        EnviromentalRisk::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('enviromentalRisk', ['id' => $id]);
    }

    public function fireSefatyRisk($id) {
        $patient = Patient::find($id);
        $fireSefatyRisk = FireSafetyRisk::where('patient_id', $id)->first();
        return view('patient.fire-sefaty-risk', compact('patient', 'fireSefatyRisk'));
    }

    public function storeFireSefatyRisk(Request $request, $id) {
        FireSafetyRisk::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('fireSefatyRisk', ['id' => $id]);
    }

    public function myHealth($id) {
        $patient = Patient::find($id);
        $myHealth = MyHealth::where('patient_id', $id)->first();
        return view('patient.my-health', compact('patient', 'myHealth'));
    }

    public function storeMyHealth(Request $request, $id) {
        $requestData = $request->all();
        if (isset($requestData['other_outcomes_check'])) {
            $requestData['other_outcomes_check'] = json_encode($requestData['other_outcomes_check']);
        }
        if (isset($requestData['other_outcomes_text'])) {
            $requestData['other_outcomes_text'] = json_encode($requestData['other_outcomes_text']);
        }
        MyHealth::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('myHealth', ['id' => $id]);
    }

    public function allergies($id) {
        $patient = Patient::find($id);
        $allergies = Allergies::where('patient_id', $id)->first();
        return view('patient.allergies', compact('patient', 'allergies'));
    }

    public function storeAllergies(Request $request, $id) {
        Allergies::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('allergies', ['id' => $id]);
    }

    public function myLifeStyle($id) {
        $patient = Patient::find($id);
        $myLifeStyle = MyLifeStyle::where('patient_id', $id)->first();
        return view('patient.my-lifestyle', compact('patient','myLifeStyle'));
    }

    public function storeMyLifeStyle(Request $request, $id) {
        MyLifeStyle::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('myLifeStyle', ['id' => $id]);
    }

    public function mobility($id) {
        $patient = Patient::find($id);
        $mobility = Mobility::where('patient_id', $id)->first();
        $checkedValues = $mobility->support_care_need ?? null;
        if ($checkedValues !== null) {
            $checkedValues = json_decode($checkedValues);
        }
        $otherCheckedValues = $mobility->other_equipment ?? null;
        if ($otherCheckedValues !== null) {
            $otherCheckedValues = json_decode($otherCheckedValues);
        }

        return view('patient.mobility', compact('patient', 'mobility', 'checkedValues', 'otherCheckedValues'));
    }

    public function storeMobility(Request $request, $id) {
        $requestData = $request->all();
        if (isset($requestData['other_outcomes_check'])) {
            $requestData['other_outcomes_check'] = json_encode($requestData['other_outcomes_check']);
        }
        if (isset($requestData['other_outcomes_text'])) {
            $requestData['other_outcomes_text'] = json_encode($requestData['other_outcomes_text']);
        }
        if (isset($requestData['equipment_place'])) {
            $requestData['equipment_place'] = json_encode($requestData['equipment_place']);
        }
        if (isset($requestData['other_equipment'])) {
            $requestData['other_equipment'] = json_encode($requestData['other_equipment']);
        }
        Mobility::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('mobility', ['id' => $id]);
    }

    public function mobilityTransferRisk($id) {
        $patient = Patient::find($id);
        $mobilityTransferRisk = MobilityAndTransferRisk::where('patient_id', $id)->first();
        return view('patient.mobility-transfer-risk', compact('patient', 'mobilityTransferRisk'));
    }

    public function storeMobilityTransferRisk(Request $request, $id) {
        MobilityAndTransferRisk::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('mobilityTransferRisk', ['id' => $id]);
    }

    public function fallsRisk($id) {
        $patient = Patient::find($id);
        $fallsRisk = FallsRisk::where('patient_id', $id)->first();
        return view('patient.falls-risk', compact('patient', 'fallsRisk'));
    }

    public function storeFallsRisk(Request $request, $id) {
        FallsRisk::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('fallsRisk', ['id' => $id]);
    }

    public function medicationRisk($id) {
        $patient = Patient::find($id);
        $medicationRisk = MedicationRisk::where('patient_id', $id)->first();
        return view('patient.medication-risk', compact('patient', 'medicationRisk'));
    }

    public function storeMedicationRisk(Request $request, $id) {
        MedicationRisk::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('medicationRisk', ['id' => $id]);
    }

    public function generalTidy($id) {
        $patient = Patient::find($id);
        $generalTidy = GeneralTidyUp::where('patient_id', $id)->first();
        return view('patient.general-tidy', compact('patient', 'generalTidy'));
    }

    public function storeGeneralTidy(Request $request, $id) {
        GeneralTidyUp::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('generalTidy', ['id' => $id]);
    }

    public function socialInterest($id) {
        $patient = Patient::find($id);
        $socialInterest = SocialInterestActivities::where('patient_id', $id)->first();
        return view('patient.social-interest', compact('patient', 'socialInterest'));
    }

    public function storeSocialInterest(Request $request, $id) {
        SocialInterestActivities::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('socialInterest', ['id' => $id]);
    }

    public function dietaryRisk($id) {
        $patient = Patient::find($id);
        $dietaryRisk = DietaryRisk::where('patient_id', $id)->first();
        return view('patient.dietary-risk', compact('patient', 'dietaryRisk'));
    }

    public function storeDietaryRisk(Request $request, $id) {
        DietaryRisk::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('dietaryRisk', ['id' => $id]);
    }

    public function restraintRisk($id) {
        $patient = Patient::find($id);
        $restraintRisk = RestraintRisk::where('patient_id', $id)->first();
        return view('patient.restraint-risk', compact('patient', 'restraintRisk'));
    }

    public function storeRestraintRisk(Request $request, $id) {
        RestraintRisk::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('restraintRisk', ['id' => $id]);
    }

    public function endLife($id) {
        $patient = Patient::find($id);
        $endLife = EndLife::where('patient_id', $id)->first();
        return view('patient.end-life', compact('patient', 'endLife'));
    }

    public function storeEndLife(Request $request, $id) {
        EndLife::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('endLife', ['id' => $id]);
    }

    public function extraNeed($id) {
        $patient = Patient::find($id);
        $extraNeed = ExtraNeed::where('patient_id', $id)->first();
        return view('patient.extra-need', compact('patient', 'extraNeed'));
    }

    public function storeExtraNeed(Request $request, $id) {
        ExtraNeed::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('extraNeed', ['id' => $id]);
    }

    public function emergencyActionPlan($id) {
        $patient = Patient::find($id);
        $emergencyActionPlan = EmergencyActionPlan::where('patient_id', $id)->first();
        return view('patient.emergency-action-plan', compact('patient', 'emergencyActionPlan'));
    }

    public function storeEmergencyActionPlan(Request $request, $id) {
        EmergencyActionPlan::updateOrCreate(['patient_id' => $id], $request->all());
        return redirect()->route('emergencyActionPlan', ['id' => $id]);
    }

    public function washAndShower($id) {
        $patient = Patient::find($id);
        $washAndShower = WashAndShower::where('patient_id', $id)->first();
        $checkedValues = $washAndShower->support_care_need ?? null;
        if ($checkedValues !== null) {
            $checkedValues = json_decode($checkedValues);
        }
        $checkedValues1 = $washAndShower->additional_thing ?? null;
        if ($checkedValues1 !== null) {
            $checkedValues1 = json_decode($checkedValues1);
        }
        return view('patient.wash-and-shower', compact('patient', 'washAndShower', 'checkedValues', 'checkedValues1'));
    }

    public function storeWashAndShower(Request $request, $id) {
        $requestData = $request->all();
        if (isset($requestData['other_outcomes_check'])) {
            $requestData['other_outcomes_check'] = json_encode($requestData['other_outcomes_check']);
        }
        if (isset($requestData['other_outcomes_text'])) {
            $requestData['other_outcomes_text'] = json_encode($requestData['other_outcomes_text']);
        }
        if (isset($requestData['support_care_need'])) {
            $requestData['support_care_need'] = json_encode($requestData['support_care_need']);
        }
        if (isset($requestData['additional_thing'])) {
            $requestData['additional_thing'] = json_encode($requestData['additional_thing']);
        }
        WashAndShower::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('washAndShower', ['id' => $id]);
    }

    public function dressingSupport($id) {
        $patient = Patient::find($id);
        $dressingSupport = DressingSupport::where('patient_id', $id)->first();
        $checkedValues = $dressingSupport->change_cloth ?? null;
        if ($checkedValues !== null) {
            $checkedValues = json_decode($checkedValues);
        }
        $checkedValues1 = $dressingSupport->upper_body_strength ?? null;
        if ($checkedValues1 !== null) {
            $checkedValues1 = json_decode($checkedValues1);
        }
        $checkedValues2 = $dressingSupport->lower_body_strength ?? null;
        if ($checkedValues2 !== null) {
            $checkedValues2 = json_decode($checkedValues2);
        }
        return view('patient.dressing-support', compact('patient', 'dressingSupport', 'checkedValues', 'checkedValues1', 'checkedValues2'));
    }

    public function storeDressingSupport(Request $request, $id) {
        $requestData = $request->all();
        if (isset($requestData['other_outcomes_text'])) {
            $requestData['other_outcomes_text'] = json_encode($requestData['other_outcomes_text']);
        }
        if (isset($requestData['change_cloth'])) {
            $requestData['change_cloth'] = json_encode($requestData['change_cloth']);
        }
        if (isset($requestData['upper_body_strength'])) {
            $requestData['upper_body_strength'] = json_encode($requestData['upper_body_strength']);
        }
        if (isset($requestData['lower_body_strength'])) {
            $requestData['lower_body_strength'] = json_encode($requestData['lower_body_strength']);
        }
        DressingSupport::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('dressingSupport', ['id' => $id]);
    }

    public function nutritionHydration($id) {
        $patient = Patient::find($id);
        $nutritionHydration = NutritionHydration::where('patient_id', $id)->first();
        $checkedValues = $nutritionHydration->maintain_nutrition ?? null;
        if ($checkedValues !== null) {
            $checkedValues = json_decode($checkedValues);
        }
        return view('patient.nutrition-hydration', compact('patient', 'nutritionHydration', 'checkedValues'));
    }

    public function storeNutritionHydration(Request $request, $id) {
        $requestData = $request->all();
        if (isset($requestData['other_outcomes_text'])) {
            $requestData['other_outcomes_text'] = json_encode($requestData['other_outcomes_text']);
        }
        if (isset($requestData['maintain_nutrition'])) {
            $requestData['maintain_nutrition'] = json_encode($requestData['maintain_nutrition']);
        }
        NutritionHydration::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('nutritionHydration', ['id' => $id]);
    }

    public function skinCare($id) {
        $patient = Patient::find($id);
        $skinCare = SkinCare::where('patient_id', $id)->first();
        $checkedValues = $skinCare->skin_integrity ?? null;
        if ($checkedValues !== null) {
            $checkedValues = json_decode($checkedValues);
        }
        return view('patient.skin-care', compact('patient', 'skinCare', 'checkedValues'));
    }

    public function storeSkinCare(Request $request, $id) {
        $requestData = $request->all();
        if (isset($requestData['other_outcomes_text'])) {
            $requestData['other_outcomes_text'] = json_encode($requestData['other_outcomes_text']);
        }
        if (isset($requestData['skin_integrity'])) {
            $requestData['skin_integrity'] = json_encode($requestData['skin_integrity']);
        }
        if (isset($requestData['cream_name'])) {
            $requestData['cream_name'] = json_encode($requestData['cream_name']);
        }
        if (isset($requestData['location_cream'])) {
            $requestData['location_cream'] = json_encode($requestData['location_cream']);
        }
        SkinCare::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('skinCare', ['id' => $id]);
    }

    public function adaptedWalsallCare($id) {
        $patient = Patient::find($id);
        $adaptedWalsallCare = AdaptedWalsallScore::where('patient_id', $id)->first();
        return view('patient.adapted-walsall-care', compact('patient', 'adaptedWalsallCare'));
    }

    public function storeAdaptedWalsallCare(Request $request, $id) {
        $requestData = $request->all();
        if (isset($requestData['other_outcomes_text'])) {
            $requestData['other_outcomes_text'] = json_encode($requestData['other_outcomes_text']);
        }
        if (isset($requestData['maintain_nutrition'])) {
            $requestData['maintain_nutrition'] = json_encode($requestData['maintain_nutrition']);
        }
        AdaptedWalsallScore::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('adaptedWalsallCare', ['id' => $id]);
    }

    public function pressureUlcerRecordTool($id) {
        $patient = Patient::find($id);
        $pressureUlcerRecordTool = PressureUlcerRecord::where('patient_id', $id)->first();
        return view('patient.pressure-ulcer-record-tool', compact('patient', 'pressureUlcerRecordTool'));
    }

    public function storePressureUlcerRecordTool(Request $request, $id) {
        $requestData = $request->all();
        PressureUlcerRecord::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('pressureUlcerRecordTool', ['id' => $id]);
    }

    public function continenceCare($id) {
        $patient = Patient::find($id);
        $continenceCare = ContinenceCare::where('patient_id', $id)->first();
        return view('patient.continence-care', compact('patient', 'continenceCare'));
    }

    public function storeContinenceCare(Request $request, $id) {
        $requestData = $request->all();
        if (isset($requestData['other_outcomes_text'])) {
            $requestData['other_outcomes_text'] = json_encode($requestData['other_outcomes_text']);
        }
        ContinenceCare::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('continenceCare', ['id' => $id]);
    }

    public function medication($id) {
        $patient = Patient::find($id);
        $medication = Medication::where('patient_id', $id)->first();
        return view('patient.medication', compact('patient', 'medication'));
    }

    public function storeMedication(Request $request, $id) {
        $requestData = $request->all();
        Medication::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('medication', ['id' => $id]);
    }

    public function preferredCallSupport($id) {
        $patient = Patient::find($id);
        $preferredCallSupport = MyPreferredCallSupport::where('patient_id', $id)->first();
        return view('patient.my-preferred-call-support', compact('patient', 'preferredCallSupport'));
    }

    public function storePreferredCallSupport(Request $request, $id) {
        $requestData = $request->all();
        MyPreferredCallSupport::updateOrCreate(['patient_id' => $id], $requestData);
        return redirect()->route('preferredCallSupport', ['id' => $id]);
    }
}

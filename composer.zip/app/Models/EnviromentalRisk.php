<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EnviromentalRisk extends Model
{
    use HasFactory;

    protected $table = 'enviromental_risk';

    protected $fillable = [
        'level_access',
        'well_lit',
        'parking_close',
        'clear_access',
        'ground_floor',
        'flooring_safe',
        'tripping_hazards',
        'environment_free',
        'food_preparation',
        'working_condition',
        'toileting_facilities',
        'personal_hygiene',
        'control_measures',
        'behaviour_member',
        'user_problem',
        'smoker_household',
        'history_violence',
        'safeguarding',
        'summon_assistance',
        'details_hazards',
        'taken_immediately',
        'personal_injury',
        'patient_id'
    ];

    public function patient() {
        return $this->belongsTo(Patient::class, 'patient_id');
    }
}
